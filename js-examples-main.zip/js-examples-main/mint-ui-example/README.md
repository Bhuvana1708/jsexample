# Mint from candy machine through the browser

In this tutorial, we will see how to mint from candy machine with wallet in the browser using the [Solana Wallet Adapter Library](https://github.com/solana-labs/wallet-adapter) and the [Metaplex JS SDK](https://github.com/metaplex-foundation/js).

The Guide is available in the [official Metaplex docs](https://docs.metaplex.com/programs/candy-machine/how-to-guides/my-first-candy-machine-part2).